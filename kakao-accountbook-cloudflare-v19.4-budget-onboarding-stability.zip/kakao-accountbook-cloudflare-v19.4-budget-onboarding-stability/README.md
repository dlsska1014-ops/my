# 똑똑한가계부 V19.4-BUDGET-ONBOARDING-STABILITY

Cloudflare Workers 단일 파일(`src/index.js`) + Supabase REST 기반 카카오 가계부 웹앱입니다.
V19.3-REPORT-CLEAN-FINAL의 안정화를 그대로 유지한 위에, 예산 모델 단순화·기록 입력 편의성·초보자 온보딩을 고도화한 버전입니다.

## V19.4에서 새로 개선된 것 (v19.3-clean-final → v19.4)

### 1. 예산: 월 전체 예산 필수 개념 제거 (자동 산정)
- **월 예산 = 분류별 예산 합계**가 기본입니다. 따로 "월 전체 예산"을 설정할 필요가 없습니다.
- 직접 설정(`__total`)은 분류 합계와 다르게 잡고 싶을 때만 쓰는 **선택 항목**으로 강등했습니다.
- 이번 달 예산 카드에 <분류 합계 자동> / <직접 설정> 모드 배지 표시.
- 직접 설정 상태에서는 "자동 산정(분류 합계)으로 전환" 원클릭 버튼 제공.
- 정합성 경고도 모드 인식: 자동 모드에서는 불필요한 "분류 합계 ≠ 전체 예산" 경고가 사라지고,
  직접 설정 모드에서만 초과 경고를 표시합니다.
- "예산 후 여유" → **"남은 배정 가능 예산"**(수입 기준 − 분류 합계)으로 명칭 정리.
- **예산 초과 저장 전 강한 경고**: 분류 예산 저장 시 합계가 수입 기준(또는 직접 설정 예산)을
  초과하면 저장 전에 초과 금액을 보여주는 confirm 경고를 띄웁니다.

### 2. /app 빠른 입력 고도화 (편한가계부/토스 벤치마킹)
- **자주 쓰는 항목 칩 자동 생성**: 이번 달 2회 이상 기록된 내용(메모)을 빈도순 상위 6개 칩으로 표시,
  탭 한 번에 내용+분류+결제수단이 채워집니다 (데이터가 적으면 기본 칩으로 폴백).
- **결제수단 칩**: 많이 쓴 결제수단 상위 4개를 원탭 선택.
- **오늘/어제 날짜 칩**: 날짜 입력 옆에서 한 번에 전환.
- 기존 금액 천단위 콤마 자동 표기 유지.

### 3. 정기지출: 이번 달 납부 예정 요약
- /reserve-plans 상단에 **이번 달 납부 예정 합계·건수·항목명** 카드 추가.

### 4. 시작가이드: 초보자용 체크리스트
- /start-guide가 실제 데이터 기반 **8단계 체크리스트**로 개편:
  가계부 만들기 → 참여자 초대 → 분류별 예산 → 결제수단 → 정기지출 → 카카오톡 기록 → 분석 → 백업.
- 각 단계의 완료 여부를 실데이터(참여자 수, 예산/자산/정기지출 등록, 챗봇 기록 유무)로 자동 판정하고
  진행률 바와 바로가기를 제공합니다. 기존 화면별 안내 탭은 그대로 유지.

---

이전 버전(V19.3-REPORT-CLEAN-FINAL)은 v19.3-report의 기능을 유지하며 운영 적용을 위한 정리·검증·문서화를 수행한 clean 버전이었습니다.

## 유지된 v19.3-report 기능

- /analysis 월간 리포트 구조, 주간 리포트(토스 스타일), 전월 대비 증감 배지
- 핵심 인사이트 카드, 분류별 지출 도넛 차트
- 최근 6개월 수입·지출 흐름, 최근 12개월 상세 표, 전월 대비 분류 변화 TOP
- 반복 지출 후보 자동 감지(매달 나가는 돈), 큰 지출 체크
- 요일별 소비 추이, 일별 소비 그래프, 캘린더 지출 히트맵(5단계)
- SERVER_DASHBOARD_CSS / MOBILE_V81_CSS 상수 분리 구조

## 이번 clean-final에서 정리한 내용

### 1. ZIP 경로 정상화
- 이전 ZIP 내부 경로가 Windows 백슬래시(`...\src\index.js`)였던 문제를 수정했습니다.
- 이제 `kakao-accountbook-cloudflare-v19.3-report-clean-final/src/index.js` 형태의 정상 경로입니다.

### 2. 버전/마커 정리
- `/health` → `version: "V19.3-REPORT-CLEAN-FINAL"`, `mode: "report-clean-final"`
- 백업 가져오기 source 마커 → `backup_import_v19_3`
- 이전 값(`backup_import_v18_8`, `global-stability-final`)은 코드에서 제거했습니다.

### 3. 캘린더 UX 정리
- /calendar: "기록 있는 날짜" 카드가 먼저 나오고, 전체 달력(히트맵 포함)은 `<details>` **기본 접힘**으로 변경.
- /my/calendar: 전체 달력이 항상 펼쳐져 모바일에서 길어지던 문제를 수정 —
  "기록 있는 날짜" 섹션을 먼저 보여주고 전체 달력은 접힘 details로 분리.

### 4. /analysis 모바일 정보량 조절 + /my/analysis 통일
- 기본 노출: 이번 달 요약(KPI), 핵심 인사이트, 주간 리포트, 일별 소비 그래프, 요일별 소비 추이
- 접기(details) 영역: 도넛 차트, 전월 대비 분류 변화, 최근 6개월 흐름(+12개월 상세), 매달 나가는 돈(반복 지출 후보), 큰 지출 체크
- /analysis와 /my/analysis 두 화면이 동일한 위젯 함수와 동일한 접기 구조를 사용합니다.

### 5. 가계부 범위(household_id) 보안 수정
- **/budgets 누출 수정**: 로그인 사용자가 쿼리스트링으로 임의 household_id를 넘기면
  다른 가계부의 예산·거래가 조회되던 문제를 수정 — 이제 참여한 가계부로만 제한됩니다.
- 최근 6/12개월 장기 분석 조회는 모두 현재 household_id로만 조회함을 검증했습니다.
- /app, /analysis, /my/*, /calendar, /reserve-plans, /payment-methods, /households, /keyword-guide 전부
  u1(h1 참여)이 h2 데이터를 볼 수 없음을 mock 런타임 테스트로 확인했습니다.

### 6. 권한별 버튼 노출 정리
- owner/admin: 예산·정기지출·자산 저장/삭제 가능 (버튼 표시)
- member/viewer/pending/blocked: 저장/삭제 버튼 미표시 + 서버측 권한 체크로 이중 차단
- /payment-methods 저장/삭제는 기존에 관리자 세션 전용이라 사용자 화면의 버튼이 동작하지 않던 문제를
  owner/admin 권한 체크 방식(예산/정기지출과 동일 패턴)으로 정리했습니다.

### 7. /budgets 정리
- 월 수입 기준 / 월 전체 예산 / 분류별 예산 합계의 정합성 경고 유지:
  분류 합계 > 월 전체 예산, 월 전체 예산 > 수입 기준 두 경우 모두 경고.
- `__income`, `__total` 내부 코드값은 사용자 화면에 그대로 노출되지 않음을 검증했습니다(한글 라벨로 변환).

### 8. /reserve-plans 정리
- 분류 입력은 직접입력 + datalist 추천목록 방식 유지.
- 매월/연1회/반기/분기 입력 방식 유지, 반복주기에 따라 납부월 칸을 자동 표시/숨김.
- owner/admin만 저장/삭제 가능(서버 체크 + 버튼 노출 제어).

### 9. /households 정리
- 로그인 사용자는 자신이 참여한 가계부만 표시.
- 참여자 관리 카드형 UI, 표시 이름(별명) 수정은 가계부 안 별명만 변경 —
  카카오 고유키(kakao_user_key/source_user_key)는 변경하지 않습니다.

## 운영 URL

| URL | 용도 |
|---|---|
| /my | 로그인/가입/가계부 없음 상태 전용 |
| /app | 홈, 입력, 기록 보기 |
| /analysis | 분석/월간 리포트 |
| /my/analysis | 사용자 분석/월간 리포트 |
| /calendar | 캘린더(히트맵) |
| /budgets | 예산 |
| /reserve-plans | 정기지출 |
| /payment-methods | 자산·결제수단 |
| /keyword-guide | 분류·키워드 |
| /households | 가계부·참여자 |

## 구조 원칙

- Cloudflare Workers 단일 파일 `src/index.js` (Node 전용 패키지/express/fs 없음)
- Supabase REST(PostgREST) 호출 구조 유지
- PC/모바일 같은 URL, CSS 반응형 대응
- 오류 시 Cloudflare Error 1101이 뜨지 않도록 safe fallback(safeHtmlRoute) 유지

## 배포

1. Cloudflare Workers 대시보드에서 기존 코드 백업
2. `src/index.js` 전체 붙여넣기 후 배포
3. `/health`에서 버전(V19.4-BUDGET-ONBOARDING-STABILITY) 확인
4. 상세 순서는 `FINAL_APPLY_CHECKLIST.md` 참조

필요 환경변수: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `ADMIN_PASSWORD`, `USER_SESSION_SECRET`(권장)
